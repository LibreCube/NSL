For ff.png, see http://www.mozilla.org/en-US/firefox/brand/downloads/

